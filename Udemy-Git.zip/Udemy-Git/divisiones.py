a = 6
b = 2
division = a/b

print(division)
