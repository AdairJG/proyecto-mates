a = 5
b = 3
multiplicacion = a*b

print(multiplicacion)
