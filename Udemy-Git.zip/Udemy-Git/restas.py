a = 7
b = 3
restas = a-b

print(restas)
