a = 5
b = 3
suma = a+b

print(suma)
